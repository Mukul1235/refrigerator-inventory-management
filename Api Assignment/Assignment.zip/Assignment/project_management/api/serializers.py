from rest_framework import serializers
from .models import Project, Task, User

class ProjectSerializer(serializers.ModelSerializer):
    class Meta:
        model = Project
        fields = '__all__'

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = '__all__'

class TaskSerializer(serializers.ModelSerializer):
    class Meta:
        model = Task
        fields = '__all__'

    def validate(self, data):
        # Validate if user has 5 active tasks
        active_tasks = Task.objects.filter(assigned_to=data['assigned_to'], status__in=['Pending', 'In Progress']).count()
        if active_tasks >= 5:
            raise serializers.ValidationError("User cannot be assigned more than 5 active tasks.")
        return data