# Project Management System API
## Setup
1. Install dependencies: `pip install -r requirements.txt`
2. Run migrations: `python manage.py makemigrations && python manage.py migrate`
3. Start the server: `python manage.py runserver`
## API Endpoints
- `POST /api/projects/`: Create a project
- `GET /api/projects/`: List projects
- ...